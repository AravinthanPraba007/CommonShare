package com.howtodoinjava.rest.controller;

import javax.servlet.http.HttpServletResponse;

import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import io.swagger.annotations.ApiOperation;
import io.swagger.annotations.ApiParam;
import net.bytebuddy.description.annotation.AnnotationList.Empty;

@RestController
@RequestMapping(path = "/media")
public class MediaController {
	
	@GetMapping(path="/download")
	 @ApiOperation(value="To download excel",
			 		notes="Gets the excel sheet",
			 		response= ResponseEntity.class)
	    public ResponseEntity<?> getExcelSheet() 
	    {
		 return null;
	    }
	
	@GetMapping(path="/export")
	 @ApiOperation(value="To export excel",
			 		notes="Gets the excel sheet",
			 		response= Empty.class)
	    public ResponseEntity<?> uploadExcelSheet(@ApiParam(value="upload the excel sheet",required = true) 
	    		HttpServletResponse response) 
	    {
		 return null;
	    }

	
	
}
