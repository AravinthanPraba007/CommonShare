package com.howtodoinjava.rest.controller;

import java.util.List;

import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.howtodoinjava.rest.model.DashboardDetails;
import com.howtodoinjava.rest.model.Event;

import io.swagger.annotations.ApiOperation;
import io.swagger.annotations.ApiParam;
import net.bytebuddy.description.annotation.AnnotationList.Empty;

@RestController
@RequestMapping(path = "/event")
public class EventController {

	
	@GetMapping(path="/dashboard")
	 @ApiOperation(value="Dashboard details",
			 		notes="Fetch the details for the dashboard page",
			 		response= DashboardDetails.class)
	    public DashboardDetails getDashboardDetails() 
	    {
		  DashboardDetails d= new DashboardDetails();
		  return d;
	    }
	
	 @GetMapping(path="/all")
	 @ApiOperation(value="Provide all the events",
			 		notes="All the events are fetched",
			 		response= Event.class,
			 		responseContainer="List")
	    public List<Event> getAllEvent() 
	    {
		 List<Event> a=(List<Event>) new Event();
	        return a;
	    }
	 
	 @GetMapping("/{eventId}")
	 @ApiOperation(value="Find the event by id",
		notes="Provide an id to look up for specific event",
		response=Event.class)
		public Event getPendingList(@ApiParam(value="Id value for the event you are searching for",required = true) 
				@PathVariable("eventId") int eventId) {
			Event a=new Event();
			return  a;
		}
	 
	 @PostMapping("/add")
	 @ApiOperation(value="To add the event",
		notes="Put the Event details in the body",
		response=Event.class)
	 public void addEvent(@ApiParam(value="Give the event details to be added",required = true) 
			 @RequestBody Event event)
	 {
		 System.out.println("post");
	 }
	 
	 @PutMapping("/edit")
	 @ApiOperation(value="To update the event details",
		notes="Put the updated event details in the body",
		response=Event.class)
	 public void editEvent(@ApiParam(value="Give the event details to be updated",required = true) 
			 @RequestBody Event event)
	 {
		 System.out.println("put"); 
	 }
	 
	 @DeleteMapping("/delete/{eventId}")
	 @ApiOperation(value="Delete the event ",
		notes="Provide the event id to deleted",
		response=Empty.class)
	 public void deleteEvent(@ApiParam(value="Id value for the event you have to delete",required = true) 
			 @PathVariable("eventId") int eventId) {
		 
	 }
}
