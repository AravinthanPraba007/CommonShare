package com.howtodoinjava.rest.model;

import java.util.Date;

public class Event {
	int event_id;
	String event_name;
	Date event_date;
	String event_status;
	String venue_address;
	
	String base_location;
	
	int total_volunteers;
	int total_volunteer_hour;
	int total_travel_hour;
	
	
	public int getEvent_id() {
		return event_id;
	}
	public void setEvent_id(int event_id) {
		this.event_id = event_id;
	}
	public String getEvent_name() {
		return event_name;
	}
	public void setEvent_name(String event_name) {
		this.event_name = event_name;
	}
	public Date getEvent_date() {
		return event_date;
	}
	public void setEvent_date(Date event_date) {
		this.event_date = event_date;
	}
	public String getEvent_status() {
		return event_status;
	}
	public void setEvent_status(String event_status) {
		this.event_status = event_status;
	}
	public String getVenue_address() {
		return venue_address;
	}
	public void setVenue_address(String venue_address) {
		this.venue_address = venue_address;
	}
	public String getBase_location() {
		return base_location;
	}
	public void setBase_location(String base_location) {
		this.base_location = base_location;
	}
	public int getTotal_volunteers() {
		return total_volunteers;
	}
	public void setTotal_volunteers(int total_volunteers) {
		this.total_volunteers = total_volunteers;
	}
	public int getTotal_volunteer_hour() {
		return total_volunteer_hour;
	}
	public void setTotal_volunteer_hour(int total_volunteer_hour) {
		this.total_volunteer_hour = total_volunteer_hour;
	}
	public int getTotal_travel_hour() {
		return total_travel_hour;
	}
	public void setTotal_travel_hour(int total_travel_hour) {
		this.total_travel_hour = total_travel_hour;
	}
	
	
	public Event() {
		super();
		// TODO Auto-generated constructor stub
	}
	
	
	

}
