package com.howtodoinjava.rest.model;

public class DashboardDetails {

	int total_event;
	int lives_impacted;
	int total_volunteers;
	int total_participants;
	
}
