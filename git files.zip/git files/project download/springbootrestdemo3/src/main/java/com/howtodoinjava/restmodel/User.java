package com.howtodoinjava.restmodel;

import java.util.Set;


public class User {
	private Long id;
	private String userID;
	private String password;

	private Set<Role> roleList;
	public Long getId() {
		return id;
	}

	public void setId(Long id) {
		this.id = id;
	}

	public String getUserID() {
		return userID;
	}

	public void setUserID(String userID) {
		this.userID = userID;
	}

	public String getPassword() {
		return password;
	}

	public void setPassword(String password) {
		this.password = password;
	}

	public Set<Role> getRoleList() {
		return roleList;
	}

	public void setRoleList(Set<Role> roleList) {
		this.roleList = roleList;
	}

	@Override
	public String toString() {
		return "User [id=" + id + ", userID=" + userID + ", password=" + password + ", roleList=" + roleList + "]";
	}

}
