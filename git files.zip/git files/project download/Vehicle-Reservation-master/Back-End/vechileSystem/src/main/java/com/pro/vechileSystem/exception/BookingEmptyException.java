package com.pro.vechileSystem.exception;

public class BookingEmptyException extends Exception {

}
