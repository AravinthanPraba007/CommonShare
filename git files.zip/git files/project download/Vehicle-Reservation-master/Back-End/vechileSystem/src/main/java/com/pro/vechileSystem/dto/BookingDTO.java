package com.pro.vechileSystem.dto;

public class BookingDTO {

}
