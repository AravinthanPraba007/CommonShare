export interface User {
    username: string;
    password: string;
    firstName: string;
    lastName: string;
    role: string;
    gender:string;
    number:string;
    age:number;
    email:string;
    branch:string;
}