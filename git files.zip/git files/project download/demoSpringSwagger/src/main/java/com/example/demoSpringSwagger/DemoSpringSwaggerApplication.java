package com.example.demoSpringSwagger;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class DemoSpringSwaggerApplication {

	public static void main(String[] args) {
		SpringApplication.run(DemoSpringSwaggerApplication.class, args);
	}

}
