
export interface Trainee {
  
    userID:string,
    firstName:string,
    lastName:string,
    contactNo:string,
    password:string,
    email:string,
    confirmPassword:string
 
}
