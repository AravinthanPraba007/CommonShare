

export interface Technology {
    skillName: string,
    tableOfContents: string,
    prerequisites: string,
    duration: string,
    image: string

}