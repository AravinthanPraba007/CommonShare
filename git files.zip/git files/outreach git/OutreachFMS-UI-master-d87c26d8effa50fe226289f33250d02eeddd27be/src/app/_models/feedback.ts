export class Feedback {
    ParticipantId: number;
    EventId: string;
    Question: string;
    Answer: string;
}
