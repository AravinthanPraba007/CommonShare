export class POCModel {
    SNo: number;
    POCID: number;
    POCName: string;
    POCContact: number;
}