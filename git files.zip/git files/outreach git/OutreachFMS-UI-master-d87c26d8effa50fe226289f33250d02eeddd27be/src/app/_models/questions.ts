import { AnswersFormValue } from './answersFormValue';

export class Questions{
    q_ID: number;
    questions: string;
    totalAnswers: number;
    fbType: string;
    answers: AnswersFormValue;
}
