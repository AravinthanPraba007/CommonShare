import React, { Component } from 'react'

export default class SignUp extends React.Component  {


    formLoginHandler = (event) => {
        console.log(event.target.username.value + " " + event.target.password.value);

        event.preventDefault();
    }
    render () {
        return(
        <div className="FristComponent">
            <h3>signup</h3>
            <form onSubmit={this.formLoginHandler} className="loginForm">
                <label>Username : </label>&nbsp;&nbsp;
                <input type="text" name="username" /><br /><br />
                <label>Role : </label>&nbsp;&nbsp;
                <input type="text" name="role" /><br /><br />
                <label>Password : </label>&nbsp;&nbsp;
                <input type="password" name="password" /><br /><br />
                <button type="submit">Login</button><br /><br />
            </form>

        </div>
        )
}
}
