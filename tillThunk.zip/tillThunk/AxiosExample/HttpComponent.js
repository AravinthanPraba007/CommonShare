import React, {Component} from 'react';
import Axios from 'axios';
import Todo from './../Todolist/Todo';
class HttpComponent extends Component {

    
    state = {
        items:[]

    }
    
   

    constructor(props){
        console.log('Constructor called');
        super(props);
    }

    static getDerivedStateFromProps(props, state) {
        console.log('getDerivedStateFromProps called');
        return state;
    }

    componentDidMount = () => {
       
        Axios.get('https://jsonplaceholder.typicode.com/todos')
        .then(function (response) {
            console.log(response);
           
            const webData=response.data;
            this.setState({items: webData});
              
            
          })
          .catch(function (error) {
            console.log(error);
          })
        
         
        console.log('componentDidMount called');
    }

    shouldComponentUpdate = (nextProps, nextState) => {
        console.log('shouldComponentUpdate called');
        return true;
    }

    getSnapshotBeforeUpdate = (prevProps, prevState) => {
        console.log('getSnapshotBeforeUpdate called');
        return {message: 'Test'};
    }

    componentDidUpdate = () => {
        console.log('componentDidUpdate called');
    }
    render() {

        const todoItems = this.state.items.map(item => {
            return <Todo key={item.id} title={item.title} />
        });
        return(
            <div>
            hello
            {todoItems}
        </div>
        )
      

    }
}
export default HttpComponent;