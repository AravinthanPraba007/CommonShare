import React from 'react'
import WithClass from './withClass';

const NormalComponent = (props) => {

    return <Auxillary>
      <p key="k1"> Child 1</p>
      <p key="k2">Child 2</p>
    </Auxillary>
}

export default WithClass(NormalComponent,'FirstComponent');