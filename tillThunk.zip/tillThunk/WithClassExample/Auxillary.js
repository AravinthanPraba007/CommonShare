const Auxiliary = props => props.childeren;

export default Auxiliary; 
