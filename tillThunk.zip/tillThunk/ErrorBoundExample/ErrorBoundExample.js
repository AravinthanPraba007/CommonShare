import React from 'react'
import NormalComponent from './NormalComponent';
import VulnerableComponent from './VulnerableComponent';
import ErrorBoundary from './ErrorBoundary';

const ErrorBoundExample = () => {

    return (
        <div>
        <NormalComponent/>
        <ErrorBoundary>
        <VulnerableComponent/>
        </ErrorBoundary>
        </div>
    )
}

export default ErrorBoundExample;