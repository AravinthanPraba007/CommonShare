import React from 'react'

const NormalComponent = () => {

    return (
        <div className="FifthComponent">
          Normal Component
               
        </div>
    )
}

export default NormalComponent;