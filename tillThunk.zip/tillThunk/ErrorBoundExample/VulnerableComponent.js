import React from 'react'

const VulnerableComponent = () => {

    const rmd=Math.random();

    if(rmd>0.7){
        throw new Error("something is wrong!!")
    }

    return (
        <div className="FifthComponent">
         
         VulnerableComponent  
        </div>
    )
}

export default VulnerableComponent;