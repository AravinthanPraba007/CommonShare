import React, { useState } from 'react';
import User from './User';

const Users = (props) => {
  const user = [
    { id: 1, name: 'Tom', email: 'tom@', phoneno: '213', favorite: true },
    { id: 2, name: 'Cat', email: 'cat@', phoneno: '345', favorite: false },
    { id: 3, name: 'Jerry', email: 'jerry@', phoneno: '678', favorite: true }
  ]
  user.forEach(element => {
    console.log(element.name);
  });


  const [currState, setState] = useState(user);

  const changeFavoriteHandler = (id) => {
    const copyUser = [...currState];
    console.log(id);
    copyUser.forEach(element => {

      if (element.id == id) {
        element.favorite = !element.favorite;
      }
    })
    setState(copyUser);
  }

  const mappedUser = currState.map(element => {
    return <User key={element.id}
      name={element.name}
      email={element.email}
      phoneno={element.phoneno}
      favorite={element.favorite}
      toggle={() => changeFavoriteHandler(element.id)}
    >
    </User>
  });

  return (
    <div>
      {mappedUser}
    </div>


  );
}

export default Users;
