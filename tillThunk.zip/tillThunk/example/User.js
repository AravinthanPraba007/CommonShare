import React from 'react';

let name = 'Aravinthan';
let email = 'xyz@gamil.com';
let phoneno = 123123;
let favorite = false;

function getName() {
  return 'Arun';
}


const User = (props) => {

  const style = {
    color: '#fff',
    backgroundColor: 'blue'
  }

  const colorChange = () => {
    console.log("hi");
    style.backgroundColor = 'red';
  }


  let actions;
  if (props.favorite) {
    actions = <div><button onClick={props.toggle}>Remove favorite</button></div>
    style.backgroundColor = 'red';
  }
  else {
    actions = <div><button onClick={props.toggle}>Add favorite</button>

    </div>

  }

  console.log(props);
  return (
    <div className="FuctionComponent" style={style}>


      <label>Name:</label> {props.name}<br></br>

      <label>Email:</label> {props.email}<br></br>

      <label>Phone no:</label> {props.phoneno}<br></br>

      <label>Favorite:</label> {props.favorite ? 'Yes' : 'No'}<br></br>

      {actions}<br></br>
    </div>
  );
}

export default User;
