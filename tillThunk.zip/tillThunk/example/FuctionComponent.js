import React from 'react';

const FuctionComponent = () => {
  return (
    <div >
      <h1>hello</h1>
      <h2>react js</h2>
    </div>
  
  );
}

export default FuctionComponent;
