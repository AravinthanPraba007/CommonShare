import React from 'react';

import './App.css';
import './example/FuctionComponent';

import User from './example/User';
import Users from './example/Users';
import Product from './shopping/Product';
import ProductList from './shopping/ProductList';
import TwoWay from './twowaybinding/TwoWay';
import TwoWayForm from './twowaybinding/TwoWayForm';
import ClassRender from './ClassRending/ClassRender';
import Todos from './Todolist/Todos';
import HttpComponent from './AxiosExample/HttpComponent';
import Login from './homework/login/Login';
import SignUp from './homework/signup/SignUp';
import NormalComponent from './ErrorBoundExample/NormalComponent';
import VulnerableComponent from './ErrorBoundExample/VulnerableComponent';
import ErrorBoundExample from './ErrorBoundExample/ErrorBoundExample';
import ErrorBoundary from './ErrorBoundExample/ErrorBoundary';
import Blog from './start/Blog';
import { BrowserRouter } from 'react-router-dom';
import MainComponent from './homework/MainComponent';
import Counter from './ReduxExample/learn/Counter';
import HomeComponent from './RestfullApp/HomeComponent';

const App = () => {
  return (
    
     <BrowserRouter>
    <div className="App">  
      {/* for users list with user and users.js */}
      {/* <User name='chris' email='xxx' phoneno='123' favorite={true}/>
     <User name='chris' email='xxx' phoneno='123' favorite={true}/>
     <User name='chris' email='xxx' phoneno='123' favorite={false}/>
     <User name='chris' email='xxx' phoneno='123' favorite={true}/>
     <User name='chris' email='xxx' phoneno='123' favorite={true}/> */}
      {/* <Users></Users> */}

      {/* for product and cart  */}

      {/* <Product id='1' name='mobile' price='20000' onSale={true}/>
      <Product id='1' name='mobile' price='20000' onSale={false}/> */}
      {/* <ProductList></ProductList> */}

      {/* Basic for 2 way binding
      <TwoWay/> */}
      {/* <TwoWayForm/> */}

      {/* Class component hooks 
      <ClassRender/> */}

      {/* <Todos/> */}

      {/* <HttpComponent/> */}

      {/* <Login />
      <SignUp/> */}

  {/* <ErrorBoundExample/> */}

  {/* <NormalComponent/>
        <ErrorBoundary>
        <VulnerableComponent/>
        </ErrorBoundary> */}

      
        {/* <Blog/> */}
        {/* <MainComponent/> */}

        {/* <Counter></Counter> */}
        <HomeComponent></HomeComponent>
    </div>
     </BrowserRouter>
  );
}

export default App;
