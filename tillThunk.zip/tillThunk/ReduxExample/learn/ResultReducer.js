

const initialState = {
    results: []
};

const ResultReducer = (state = initialState, action) => {
    switch(action.type) {
        case 'ON_STORE':
            console.log()
            //any logic to change data
            return {
                ...state, 
                results:state.results.concat({value:action.value})
            };
        
        default:
            return state;
    }
}

export default ResultReducer;