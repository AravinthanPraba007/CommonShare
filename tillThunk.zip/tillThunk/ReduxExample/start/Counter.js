import React, { Component } from 'react';
import CounterControl from './CounterControl/CounterControl';
import CounterOutput from './CounterOutput/CounterOutput';
import { connect } from'react-redux';


const mapStateToprops = state => {
    return {
        ctr:state.counter,
        storedResult:state.results,
    };
};

 const mapDispatchToPros = dispatch => {
    return {
        onIncrementCounter: () => dispatch({}),
        onDecrementCounter: () => dispatch({type:'DEC_COUNTER'}),
        onAddCounter: () => dispatch({type:'ADD_COUNTER',value:5}),
        onSubCounter: () => dispatch({type:'SUB_COUNTER',value:5}),
        onStoreCounter: () => dispatch({type:'ON_STORE'})
    };
};



class Counter extends Component {

    render () {
        return (
            [
            <div>
                <CounterOutput value={this.props.ctr} />
                
                {/* <CounterOutput value='0' /> */}
                <CounterControl label="Increment" clicked={this.props.onIncrementCounter}/>
                <CounterControl label="Decrement" clicked={this.props.onDecrementCounter}/>
                <CounterControl label="Add 5" clicked={this.props.onAddCounter}/>
                <CounterControl label="Subtract 5" clicked={this.props.onSubCounter}/>
                <hr/>
                <button onClick={this.props.onStoreCounter}>Store Result</button>
            </div>,
            <div>
                {
                this.props.storedResult.map(result=>{
                    return<div>{result.value}</div>
                })
                }
            </div>
            ]

        );
    }
}

export default connect(mapStateToprops,mapDispatchToPros)(Counter);