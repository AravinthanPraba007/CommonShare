import React from "react";

const Login = () => {


    const formLoginHandler = (event) => {
        console.log(event.target.username.value + " " + event.target.password.value);

        event.preventDefault();
    }
    return (
        <div className="FristComponent">
            <h3>Login</h3>
            <form onSubmit={formLoginHandler} className="loginForm">
                <label>Username : </label>&nbsp;&nbsp;
                <input type="text" name="username" /><br /><br />
                <label>Password : </label>&nbsp;&nbsp;
                <input type="password" name="password" /><br /><br />
                <button type="submit">Login</button><br /><br />
            </form>

        </div>
    )
}

export default Login;