import React from 'react';

import { Route, Switch } from 'react-router';

import { BrowserRouter, Link, NavLink } from 'react-router-dom';
import Posts from '../start/Posts';
import NewPost from '../start/NewPost';
import FullPost from '../start/FullPost';
import Login from './login/Login';
import SignUp from './signup/SignUp';
import Users from './Users/Users';
import RestfulUsers from './Users/RestfulUsers';
import RestfulCommentList from './Users/RestfulCommentList';
import RestfulPostList from './Users/RestfulPostList';

export default class MainComponent extends React.Component {

    render () {
        return <div>
            <header>
                <ul>
                    <li><NavLink to="/login">Login</NavLink></li>
                    <li><NavLink to="/sigup">Signup</NavLink></li>
                    <li> <NavLink to="/users">Users</NavLink></li>
 
                </ul>
            </header>
            <section>
                <div style={{clear:'both'}}>
 
                       <Route path="/login" component={Login}/>
                      <Route path="/sigup" component={SignUp}/>
                      <Route path="/users" component={RestfulUsers}/>
                      <Route path="/user/:id" component={RestfulPostList}/>
                      <Route path="/post/:id" component={RestfulCommentList}/>
                     
                      
                </div>
            </section>
        </div>
    }

}