import React, { Component } from 'react'
import Axios from 'axios';
import Users from './Users';

class RestfulCommentList extends Component {

    state = {
        users: []

    }
    
    static getDerivedStateFromProps(props, state) {
        console.log(props);
        return state;
    }

    componentDidMount = () => {
        // Axios.get("https://jsonplaceholder.typicode.com/users")
        //     .then(res => {
        //         this.setState({ users: res.data, post: this.state.post, signup: this.state.signup });
        //     })
    }

  
    userClickedHandler = (id) =>{
        this.props.history.push({pathname:'/user/'+id})
    }
   
    
    render () {
        const userList = this.state.users.map(item => {
            return <Users key={item.id} username={item.name} id={item.id} clicked={()=>this.userClickedHandler(item.id)}/>
        });
        return (
            <div>
                {/* {userList} */}
                hello
            </div>
            
        );

    }

    shouldComponentUpdate = (nextProps, nextState) => {
        return true;
    }

    getSnapshotBeforeUpdate = (prevProps, prevState) => {
        return { message: 'Test' };
    }

    componentDidUpdate = () => {

    }
   
}

export default RestfulCommentList;