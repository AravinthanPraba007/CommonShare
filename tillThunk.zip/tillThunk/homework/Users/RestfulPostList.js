import React, { Component } from 'react'
import Axios from 'axios';
import Users from './Users';
import PostList from './PostList';

class RestfulPostList extends Component {

    state = {
        post: []

    }
    
    static getDerivedStateFromProps(props, state) {
        console.log(props);
        return state;
    }

    componentDidMount = () => {
        const postId = this.props.match.params.id;
        console.log(postId);
        Axios.get("https://jsonplaceholder.typicode.com/posts?userId=" + postId)
        .then(res => {
            this.setState({  post: res.data });
        })
    }

  
    commentClickedHandler = (id) => {
        
        this.props.history.push({pathname:'/post/'+id})
    }
    
    
    render () {
        const postList = this.state.post.map(item => {
            return <PostList key={item.id} title={item.title} body={item.body} clicked={() => this.commentHandler(item.id)} />
        });
       
        return (
            <div>
                {/* {userList} */}
                User Id : {this.props.match.params.id}
                {postList}
            </div>
            
        );

    }

    shouldComponentUpdate = (nextProps, nextState) => {
        return true;
    }

    getSnapshotBeforeUpdate = (prevProps, prevState) => {
        return { message: 'Test' };
    }

    componentDidUpdate = () => {

    }
   
}

export default RestfulPostList;