import React, { useState } from 'react';
const Cart = (props) => {
    return (
        <div className="Cart" >
            <label>Name : </label> {props.name}<br></br>
            <label>Price : </label> {props.price}<br></br>
            <label>Count : </label> {props.number}<br></br>
            <button onClick={props.deleteCart}>Delete Item</button>
        </div>
    )
}

export default Cart;