import React, { useState } from 'react';
import Product from './Product';
import Cart from './Cart';

const ProductList = (props) => {
  const products = [
    { id: 1, name: 'mobile', price: '100', onSale: true, number:1 },
    { id: 2, name: 'tv', price: '150', onSale: false ,number:1},
    { id: 3, name: 'ac', price: '250', onSale: true ,number:1},
    { id: 4, name: 'car', price: '500', onSale: true ,number:1}
   
  ]
 
  const cartList=[];
  const [currState, setState] = useState({product:products,cartListing:cartList});
  // console.log(currState.cartList);
  const copyProducts = [...currState.product];
  const addItem = (id) => {
   console.log("adding");
    copyProducts.forEach(element => {
      if(element.id==id){
        if(currState.cartListing.length!=0)
        {
          const filterValue=currState.cartListing.filter(element =>{
            return element.id==id;
          });
          console.log(filterValue);
          if(filterValue.length>0) {
            currState.cartListing.forEach(cartElement =>{
              if(cartElement.id==id) {
                cartElement.number+=1;
              }
             
            });
          }
          else {
           
            currState.cartListing.push(element);
          }
         
        }
        else
        {
          currState.cartListing.push(element);
        }
       
      }
    });
    console.log(currState.cartListing);
    console.log(id);

    setState({product:copyProducts,cartListing:currState.cartListing});
}

  
const deleteItem = (id) => {
  console.log("clicked"+id);
  copyProducts.forEach(element => {
    if(element.id==id){
      var index=currState.cartListing.indexOf(element);
      console.log(index);
      currState.cartListing.slice(index,1);
    }
  });
  console.log(currState.cartListing);
  setState({product:copyProducts,cartListing:currState.cartListing});
}

  
  const mappedProduct = currState.product.map(element => {
    return <Product key={element.id}
      id={element.id}
      name={element.name}
      price={element.price}
      onSale={element.onSale}
      
      addCart={()=> addItem(element.id) }

    >
    </Product>
  });

  let totalPrice=0;
  const mappedCart = currState.cartListing.map(element => {
    totalPrice+=(element.price*element.number);
    return <Cart key={element.id}
    id={element.id}
    name={element.name}
    price={element.price}
    number={element.number}
    
    deleteCart={()=> deleteItem(element.id)}
    >

    </Cart>
  });
 
  let totalElementPrice;

  if(totalPrice>0)
  {
  totalElementPrice=<div>
    <h1> Your Cart </h1>
  <div>
      {mappedCart}
    </div>
    <h1>Total price ={totalPrice}</h1>
    </div>
  }
  return (
    <div>

    
    <div>
      {mappedProduct}
    </div>
    
      {totalElementPrice}
    </div>

  );
}

export default ProductList;
