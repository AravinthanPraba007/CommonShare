import React from 'react';



const Product = (props) => {

  const onSaleStyle ={
    backgroundColor: 'green'
  }

  if(props.onSale){
    onSaleStyle.backgroundColor='green';
  }
  else {
    onSaleStyle.backgroundColor='yellow';
  }
 
  let button;
  if(props.onSale)
  {
    button= <div>
     
      <button onClick={props.addCart}>Add to cart</button>
    </div> ;
  }
  return (
    
     <div className="Product" >
       <div style={onSaleStyle}>
         <h2>{props.onSale ? 'Onsale' : 'Not in sale'}</h2>
       </div>
       <label>Id: </label> {props.id}<br/>
       <label>Name: </label> {props.name}<br/>
       <label>Price: </label> {props.price}<br/>
     
      {button}
      
      
     </div>
    
  );
}

export default Product;
