import React from 'react';
import './Post.css';
import { Route } from 'react-router';
import FullPost from './FullPost';
import { BrowserRouter } from 'react-router-dom';

const Post = (props) => {
    return <div>
        
    <div className='Post' onClick={props.clicked}>
        
        <h3>{props.post.title}</h3>
       
        
        </div>
      
       
       
       
        </div>
        
}

export default Post;