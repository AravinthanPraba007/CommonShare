import React, { Component } from 'react';

class ClassRender extends React.Component {
  
  
  state={
     textInput: '', 
    dropInput:''
  };

  inputChangedHandler = (event) => {
  //  console.log("input changed");
   const textValue=event.target.value;
   this.setState({textInput:textValue});
    console.log(textValue);
  

  }

  dropChangedHandler = (event) => {
    // console.log("clickeddrop");
    const dropValue=event.target.value;
    this.setState({dropInput:dropValue})
    console.log(dropValue);
     
  }

  sumbitClicked (event) {
    event.preventDefault();
    console.log(this.state);
    console.log("clickedform");
  }

  showTitle=() =>{
    console.log(this.state.textInput);

    console.log("clickedserach");
   
  }
  render() {
    return (
      <div className="FristComponent">
        <h1>Input form</h1>
        <form onSubmit={(event) => this.sumbitClicked(event)}>
          <label>Title  </label>
          <input type="text" value={this.state.textInput} onChange={(event) => this.inputChangedHandler(event)} />
          <button onClick={this.showTitle}>Search</button>
          <br></br>
          <label>Role </label>
          <select name="role" onChange={(event) => this.dropChangedHandler(event)} >
            <option value="tester">Tester</option>
            <option value="developer">Developer</option>
            <option value="devops">DEVOPS</option>
          </select>
          <input type="submit" value="sumbit now"></input>
        </form>
      </div>
    );
  }

}

export default ClassRender;
