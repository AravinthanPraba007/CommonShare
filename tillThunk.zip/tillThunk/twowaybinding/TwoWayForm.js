import React, { useState } from 'react';

const TwoWayForm = () => {
  const data = '';
  const [curState, setState] = useState({ textInput: "welcome", dropInput: '', count: 0 });

  const inputChangedHandler = (event) => {
    const updatedKeyword = event.target.value;
    curState.textInput = updatedKeyword;
    // console.log(updatedKeyword);
    setState({ textInput: curState.textInput, dropInput: curState.dropInput, count: curState.count });
  }

  const dropChangedHandler = (event) => {
    const updatedDropvalue = event.target.value;
    curState.dropInput = updatedDropvalue;
    // console.log(curState.dropInput);
    setState({ textInput: curState.textInput, dropInput: curState.dropInput, count: curState.count });
  }

  const showTitle = () => {
    console.log(curState.textInput);
  }

  const sumbitClicked = (event) => {
    event.preventDefault();
    console.log(curState.textInput);
    console.log(curState.dropInput);
  }

  const countAdd = () => {
    curState.count += 1;
    setState({ textInput: curState.textInput, dropInput: curState.dropInput, count: curState.count });
  }
  return (
    <div>
      <div className="FristComponent">
        <h1>Input form</h1>
        <form onSubmit={(event) => sumbitClicked(event)}>
          <label>Title  </label>
          <input type="text" value={curState.textInput} onChange={(event) => inputChangedHandler(event)} />
          <button onClick={showTitle}>Search</button>
          <br></br>
          <label>Role </label>
          <select name="role" onChange={(event) => dropChangedHandler(event)} >
            <option value="tester">Tester</option>
            <option value="developer">Developer</option>
            <option value="devops">DEVOPS</option>
          </select>
          <input type="submit" value="sumbit now"></input>
        </form>
      </div>
      <div class="SecondComponent">
        <h1>Count Counter</h1>
        <label>Count :</label>{curState.count}<br></br>
        <button onClick={countAdd}>Click me</button>
      </div>
    </div>


  );
}

export default TwoWayForm;
