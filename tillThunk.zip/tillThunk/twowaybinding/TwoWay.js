import React, { useState } from 'react';

const TwoWay = () => {
  const data = '';
  const [curState, setState] = useState({ inputdata: "welcome" });

  const inputChangedHandler = (event) => {
    const updatedKeyword = event.target.value;
    curState.inputdata = updatedKeyword;
    console.log(updatedKeyword);
    setState({ inputdata: curState.inputdata });
  }

 

  return (
    <div >
      <h1>Title</h1>
      <h2>- {curState.inputdata} -</h2>
      <label>Title  </label>
      <input type="text" value={curState.inputdata} onChange={(event) => inputChangedHandler(event)}></input><br></br>
     
    </div>

  );
}

export default TwoWay;
