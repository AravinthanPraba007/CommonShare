import React, { Component } from 'react';
import { connect } from 'react-redux';
import * as actionCreactor from './../Redux/Action';



const mapStateToprops = state => {
    return {
        ctr:state.counter,
        storedResult:state.results,
    };
};

 const mapDispatchToPros = dispatch => {
    
    return {
        
        
        onSignupCounter: () =>
        {
            
            dispatch(actionCreactor.onSignupCounter())
        },

        onSignup: (val) =>
        {
            
            dispatch(actionCreactor.onSignup(val))
        }
        
    };
};

 class SignUp extends React.Component  {


    formSignupHandler = (event) => {
        
        const name=event.target.username.value;
        console.log(name);
        
        this.props.onSignupCounter();
        this.props.onSignup(name);
        event.preventDefault();
    }
    render () {
        return(
            [
        <div className="FristComponent">
            <h3>SignUp </h3>
            
            <form onSubmit={this.formSignupHandler} className="loginForm">
                <label>Username : </label>&nbsp;&nbsp;
                <input type="text" name="username" /><br /><br />
                
                <button type="submit">SignUp</button><br /><br />
            </form>

        </div>,
        <div>
            <h3>No of Users {this.props.ctr}</h3>
            <h2>List of users</h2>
            {
                this.props.storedResult.map(result=>{
                    return<div>{result.value}</div>
                })
                }
        </div>
        ]
        )
}
}

export default connect(mapStateToprops,mapDispatchToPros)(SignUp);