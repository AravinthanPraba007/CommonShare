import React from 'react';

import { Route, Switch } from 'react-router';


import { BrowserRouter, Link, NavLink } from 'react-router-dom';
import Login from './Login/Login';
import SignUp from './Signup/Signup';
export default class HomeComponent extends React.Component {

    render () {
        return <div>
            <header>
                <ul>
                    <li><NavLink to="/login">Login</NavLink></li>
                    <li><NavLink to="/sigup">Signup</NavLink></li>
                    {/* <li> <NavLink to="/users">Users</NavLink></li> */}
 
                </ul>
            </header>
            <section>
                <div style={{clear:'both'}}>
 
                       <Route path="/login" component={Login}/>
                      <Route path="/sigup" component={SignUp}/>
                      {/* <Route path="/users" component={RestfulUsers}/>
                      <Route path="/user/:id" component={RestfulPostList}/> */}
     
                      
                </div>
            </section>
        </div>
    }

}