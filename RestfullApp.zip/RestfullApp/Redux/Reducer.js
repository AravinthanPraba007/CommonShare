const initialState = {
    counter: 0,
    results:[]
}

const Reducer = (state = initialState, action) => {

  
 
     if(action.type == 'ON_SIGNUP_COUNTER') {
       
        return {
            
            ...state,
        //    results:state.results.concat({name:action.name})
        counter:state.counter+1
        }
    }
    else if(action.type == 'ON_SIGNUP') {
        
        return {
            ...state,
            results:state.results.concat({value:action.value})
        }
    }

    return state;
}
export default Reducer;