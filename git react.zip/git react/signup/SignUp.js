import React, { Component } from 'react'
import Axios from 'axios';
import Users from '../Users/Users';
import PostList from '../Users/PostList';
import CommentList from '../Users/CommendList';

class SignUp extends Component{

    state = {
        users : [],
        post : [],
        comment : [],
        addPost : {userId:0, id:0,title:'',body:''},
        signup : {id:0,name:'',username:'',email:'',address:{street:'',suite:'',city:'',zipcode:'',
                    geo:{lat:'',lng:''}},phone:0,website:''}

    }
    
    
    static getDerivedStateFromProps(props, state) {
        return state;
    }

    postHandler = (id) => {
        Axios.get("https://jsonplaceholder.typicode.com/posts?userId="+id)
        .then(res => {
             this.setState({users:this.state.users,post:res.data,signup:this.state.signup});
        })
    }

    commentHandler = (id) => {
        Axios.get("https://jsonplaceholder.typicode.com/comments?postId="+id)
        .then(res => {
             this.setState({users:this.state.users,post:this.state.post,signup:this.state.signup,comment:res.data});
        })
    }

    removeCommentHandler = (id) => {
        const cmt = [...this.state.comment];
        const otherComments = cmt.filter(i=>i.id !== id);
        this.setState({users:this.state.users,post:this.state.post,signup:this.state.signup,comment:otherComments});
    }

    formNameHandler = (event) => {
        this.setState({users:this.state.users,post:this.state.post,signup:{name:event.target.value}});
    }

    formUserNameHandler = (event) => {
        this.setState({users:this.state.users,post:this.state.post,signup:{name:this.state.signup.name,username:event.target.value}});
    }

    formEmailHandler = (event) => {
        this.setState({users:this.state.users,post:this.state.post,signup:{name:this.state.signup.name,username:this.state.signup.username,email:event.target.value}});
    } 
    
    formStreetHandler = (event) => {
        this.setState({users:this.state.users,post:this.state.post,signup:{name:this.state.signup.name,username:this.state.signup.username,email:this.state.signup.username,
                        address:{street:event.target.value}}});
    }

    formSuiteHandler = (event) => {
        this.setState({users:this.state.users,post:this.state.post,signup:{name:this.state.signup.name,username:this.state.signup.username,email:this.state.signup.username,
            address:{street:this.state.signup.address.street,suite:event.target.value}}});
    }

    formCityHandler = (event) => {
        this.setState({users:this.state.users,post:this.state.post,signup:{name:this.state.signup.name,username:this.state.signup.username,email:this.state.signup.username,
            address:{street:this.state.signup.address.street,suite:this.state.signup.address.suite,city:event.target.value}}});
    }

    formZipcodeHandler = (event) => {
        this.setState({users:this.state.users,post:this.state.post,signup:{name:this.state.signup.name,username:this.state.signup.username,email:this.state.signup.username,
            address:{street:this.state.signup.address.street,suite:this.state.signup.address.suite,city:this.state.signup.address.city,
            zipcode:event.target.value}}});
    }

    formLatituteHandler = (event) => {
        this.setState({users:this.state.users,post:this.state.post,signup:{name:this.state.signup.name,username:this.state.signup.username,email:this.state.signup.username,
            address:{street:this.state.signup.address.street,suite:this.state.signup.address.suite,city:this.state.signup.address.city,
            zipcode:this.state.signup.address.zipcode,geo:{lat:event.target.value}}}});
    }

    formLongituteHandler = (event) => {
        this.setState({users:this.state.users,post:this.state.post,signup:{name:this.state.signup.name,username:this.state.signup.username,email:this.state.signup.username,
            address:{street:this.state.signup.address.street,suite:this.state.signup.address.suite,city:this.state.signup.address.city,
            zipcode:this.state.signup.address.zipcode,geo:{lat:this.state.signup.address.geo.lat,lng:event.target.value}}}});
    }

    formPhoneNumberHandler = (event) => {
        this.setState({users:this.state.users,post:this.state.post,signup:{name:this.state.signup.name,username:this.state.signup.username,email:this.state.signup.username,
            address:{street:this.state.signup.address.street,suite:this.state.signup.address.suite,city:this.state.signup.address.city,
            zipcode:this.state.signup.address.zipcode,geo:{lat:this.state.signup.address.geo.lat,lng:this.state.signup.address.geo.lat}},
        phone:event.target.value}});
    }

    formWebsiteHandler =(event) => {
        this.setState({users:this.state.users,post:this.state.post,signup:{name:this.state.signup.name,username:this.state.signup.username,email:this.state.signup.username,
            address:{street:this.state.signup.address.street,suite:this.state.signup.address.suite,city:this.state.signup.address.city,
            zipcode:this.state.signup.address.zipcode,geo:{lat:this.state.signup.address.geo.lat,lng:this.state.signup.address.geo.lat}},
        phone:this.state.signup.phone,website:event.target.value}});
    }

    formSignUphandler = () => {
       console.log(this.state);
       const lenght = this.state.users.length +1;
       this.setState({users:this.state.users,post:this.state.post,signup:{id:lenght,name:this.state.signup.name,username:this.state.signup.username,email:this.state.signup.username,
        address:{street:this.state.signup.address.street,suite:this.state.signup.address.suite,city:this.state.signup.address.city,
        zipcode:this.state.signup.address.zipcode,geo:{lat:this.state.signup.address.geo.lat,lng:this.state.signup.address.geo.lat}},
    phone:this.state.signup.phone,website:this.state.signup.website}});
    this.pushSignUp();
   }
   
   pushSignUp = () => {
   console.log(this.state.users.push(this.state.signup));
   console.log(this.state);
    this.setState({users:this.state.users,post:this.state.post,signup:{id:this.state.signup.id,name:this.state.signup.name,username:this.state.signup.username,email:this.state.signup.username,
        address:{street:this.state.signup.address.street,suite:this.state.signup.address.suite,city:this.state.signup.address.city,
        zipcode:this.state.signup.address.zipcode,geo:{lat:this.state.signup.address.geo.lat,lng:this.state.signup.address.geo.lat}},
    phone:this.state.signup.phone,website:this.state.signup.website}});
   }

   addPostTitleHandller = (event) => {
        this.setState({users:this.state.users,post:this.state.post,signup:this.state.signup,addPost:{title:event.target.value}})
   }

   addPostBodyHandller = (event) => {
    this.setState({users:this.state.users,post:this.state.post,signup:this.state.signup,addPost:{title:this.state.addPost.title,
                    body:event.target.value}})
   }

   savePostHandler = () => {
        console.log(this.state.post.push(this.state.addPost));
        console.log(this.state);
        this.setState({users:this.state.users,post:this.state.post,signup:this.state.signup,addPost:this.state.addPost});
   }

    render() {
        
        const userList = this.state.users.map(item => {
            return <Users key={item.id} username={item.name} post={()=>this.postHandler(item.id)}/>
        });
        const postList = this.state.post.map(item => {
            return <PostList key={item.id} title={item.title} body={item.body} comment={()=>this.commentHandler(item.id)}/>
        });
        const commentList = this.state.comment.map(item => {
            return <CommentList key={item.id} name={item.name} email={item.email} body={item.body} removeComment={()=>this.removeCommentHandler(item.id)}/>
        });
        
        return (
                <div>
                        <form className="signUpForm">
                            <label>Name  :</label>&emsp;&emsp;
                            <input type = "text" onChange={this.formNameHandler}/><br/>
                            <label>Username  :</label>&emsp;&emsp;
                            <input type = "text" onChange={this.formUserNameHandler}/><br/>
                            <label>Email  :</label>&emsp;&emsp;
                            <input type = "text" onChange={this.formEmailHandler}/><br/>
                            <label>Street  :</label>&emsp;&emsp;
                            <input type = "text" onChange={this.formStreetHandler}/><br/>
                            <label>Suite  :</label>&emsp;&emsp;
                            <input type = "text" onChange={this.formSuiteHandler}/><br/>
                            <label>City  :</label>&emsp;&emsp;
                            <input type = "text" onChange={this.formCityHandler}/><br/>
                            <label>Zipcode  :</label>&emsp;&emsp;
                            <input type = "text" onChange={this.formZipcodeHandler}/><br/>
                            <label>Latitute  :</label>&emsp;&emsp;
                            <input type = "text" onChange={this.formLatituteHandler}/><br/>
                            <label>Longitute  :</label>&emsp;&emsp;
                            <input type = "text" onChange={this.formLongituteHandler}/><br/>
                            <label>Phone Number  :</label>&emsp;&emsp;
                            <input type = "text" onChange={this.formPhoneNumberHandler}/><br/>
                            <label>Website  :</label>&emsp;&emsp;
                            <input type = "text" onChange={this.formWebsiteHandler}/><br/>
                            <button type="button" onClick={this.formSignUphandler}>Signup</button>
                        </form>
                    <div>
                            <p>
                                &emsp;&emsp;&emsp;Name&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;
                                &emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;
                                &emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;Action<br/>
                            </p>
                            {userList}
                            {postList}
                            <form className="users">
                                <label>Title</label><br/>
                                <input type="text" onChange={this.addPostTitleHandller} /><br/>
                                <label>Body</label><br/>
                                <input type="text" onChange={this.addPostBodyHandller} /><br/>
                                <button type="button" onClick={this.savePostHandler}>Save</button>
                            </form>
                            {commentList}
                    </div>
                </div>
               );
    }

    componentDidMount = () => {
        Axios.get("https://jsonplaceholder.typicode.com/users")
        .then(res => {
            this.setState({users:res.data,post:this.state.post,signup:this.state.signup});
        })
    }

    shouldComponentUpdate = (nextProps, nextState) => {
        return true;
    }

    getSnapshotBeforeUpdate = (prevProps, prevState) => {
        return {message: 'Test'};
    }

    componentDidUpdate = () => {
        
    }
}
 

export default SignUp;