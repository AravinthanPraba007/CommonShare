import React from 'react'

const PostList = (props) => {

    return (
        <div>
            <div> 
                <ul>
                    <li>
                        <h5>Title</h5>       
                        {props.title}<br/>
                        <h5>Body</h5>       
                        {props.body}<br/>
                        <center><button onClick={props.comment}>Comment</button></center>
                    </li>
                </ul>
            </div>

        </div>
    )
}

export default PostList;