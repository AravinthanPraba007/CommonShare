import React from 'react'

const Users = (props) => {

    return (
        <div>
            <div className="users"> 
                <ul>
                    <li>
                {props.username}&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;
                <center><button onClick={props.post}>POST</button></center>
                    </li>
                </ul>
            </div>

        </div>
    )
}

export default Users;