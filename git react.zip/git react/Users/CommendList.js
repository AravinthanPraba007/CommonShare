import React from 'react'

const CommentList = (props) => {
    
    return (
        <div>
            <div className="users"> 
                <ul>
                    <li>
                        <h5>Name</h5>       
                        {props.name}<br/>
                        <h5>Email</h5>       
                        {props.email}<br/>
                        <h5>Body</h5>       
                        {props.body}<br/>
                        <center><button onClick={props.removeComment}>Remove Comment</button></center>
                    </li>
                </ul>
            </div>

        </div>
    )
}

export default CommentList;