import React from 'react';
import './App.css';
// import Datas from './jsonDataUrl/Data'
import Login from './login/Login';
import SignUp from './signup/SignUp';


const App = () => {
  return (
    <div>
        {/* <FunctionComponent/> */}
        {/* <ClassComponent /> */}
        {/* <Todos /> */}
        {/* <Datas /> */}
        <Login />
        <SignUp />
        {/* <User/> */}
        </div>
  );
}

export default App;
