import React, { Component } from 'react'
import Axios from 'axios';
import Users from '../Users/Users';
import PostList from '../Users/PostList';
import CommentList from '../Users/CommendList';

class SignUp extends Component {

    state = {
        users: [],
        post: [],
        comment: [],
        addPost: { userId: 0, id: 0, title: '', body: '' },
        signup: {
            id: 0, name: '', username: '', email: '', address: {
                street: '', suite: '', city: '', zipcode: '',
                geo: { lat: '', lng: '' }
            }, phone: 0, website: ''
        }

    }


    static getDerivedStateFromProps(props, state) {
        return state;
    }

    postHandler = (id) => {
        Axios.get("https://jsonplaceholder.typicode.com/posts?userId=" + id)
            .then(res => {
                this.setState({ users: this.state.users, post: res.data, signup: this.state.signup });
            })
    }

    commentHandler = (id) => {
        Axios.get("https://jsonplaceholder.typicode.com/comments?postId=" + id)
            .then(res => {
                this.setState({ comment: res.data });
            })
    }

    removeCommentHandler = (id) => {
        const cmt = [...this.state.comment];
        const otherComments = cmt.filter(i => i.id !== id);
        this.setState({ comment: otherComments });
    }

    formNameHandler = (event) => {
        this.setState({ signup: { name: event.target.value } });
    }

    formUserNameHandler = (event) => {
        this.setState({ signup: { name: this.state.signup.name, username: event.target.value } });
    }

    formEmailHandler = (event) => {
        this.setState({ signup: { name: this.state.signup.name, username: this.state.signup.username, email: event.target.value } });
    }

    formStreetHandler = (event) => {
        this.setState({
            signup: {
                name: this.state.signup.name, username: this.state.signup.username, email: this.state.signup.username,
                address: { street: event.target.value }
            }
        });
    }

    formSuiteHandler = (event) => {
        this.setState({
            signup: {
                name: this.state.signup.name, username: this.state.signup.username, email: this.state.signup.username,
                address: { street: this.state.signup.address.street, suite: event.target.value }
            }
        });
    }

    formCityHandler = (event) => {
        this.setState({
            signup: {
                name: this.state.signup.name, username: this.state.signup.username, email: this.state.signup.username,
                address: { street: this.state.signup.address.street, suite: this.state.signup.address.suite, city: event.target.value }
            }
        });
    }

    formZipcodeHandler = (event) => {
        this.setState({
            users: this.state.users, post: this.state.post, signup: {
                name: this.state.signup.name, username: this.state.signup.username, email: this.state.signup.username,
                address: {
                    street: this.state.signup.address.street, suite: this.state.signup.address.suite, city: this.state.signup.address.city,
                    zipcode: event.target.value
                }
            }
        });
    }

    formLatituteHandler = (event) => {
        this.setState({
            signup: {
                name: this.state.signup.name, username: this.state.signup.username, email: this.state.signup.username,
                address: {
                    street: this.state.signup.address.street, suite: this.state.signup.address.suite, city: this.state.signup.address.city,
                    zipcode: this.state.signup.address.zipcode, geo: { lat: event.target.value }
                }
            }
        });
    }

    formLongituteHandler = (event) => {
        this.setState({
            signup: {
                name: this.state.signup.name, username: this.state.signup.username, email: this.state.signup.username,
                address: {
                    street: this.state.signup.address.street, suite: this.state.signup.address.suite, city: this.state.signup.address.city,
                    zipcode: this.state.signup.address.zipcode, geo: { lat: this.state.signup.address.geo.lat, lng: event.target.value }
                }
            }
        });
    }

    formPhoneNumberHandler = (event) => {

        this.setState({
            signup: {
                name: this.state.signup.name, username: this.state.signup.username, email: this.state.signup.username,
                address: {
                    street: this.state.signup.address.street, suite: this.state.signup.address.suite, city: this.state.signup.address.city,
                    zipcode: this.state.signup.address.zipcode, geo: { lat: this.state.signup.address.geo.lat, lng: this.state.signup.address.geo.lat }
                },
                phone: event.target.value
            }
        });
    }

    formWebsiteHandler = (event) => {

        this.setState({
            signup: {
                name: this.state.signup.name, username: this.state.signup.username, email: this.state.signup.username,
                address: {
                    street: this.state.signup.address.street, suite: this.state.signup.address.suite, city: this.state.signup.address.city,
                    zipcode: this.state.signup.address.zipcode, geo: { lat: this.state.signup.address.geo.lat, lng: this.state.signup.address.geo.lat }
                },
                phone: this.state.signup.phone, website: event.target.value
            }
        });
    }

    formSignUphandler = () => {
        console.log(this.state);
        const lenght = this.state.users.length + 1;

        this.setState({
            signup: {
                id: lenght, name: this.state.signup.name, username: this.state.signup.username, email: this.state.signup.username,
                address: {
                    street: this.state.signup.address.street, suite: this.state.signup.address.suite, city: this.state.signup.address.city,
                    zipcode: this.state.signup.address.zipcode, geo: { lat: this.state.signup.address.geo.lat, lng: this.state.signup.address.geo.lat }
                },
                phone: this.state.signup.phone, website: this.state.signup.website
            }
        });
        this.pushSignUp();
    }

    pushSignUp = () => {

        console.log(this.state.users.push(this.state.signup));
        console.log(this.state);

        this.setState({
            users: this.state.users, post: this.state.post, signup: {
                id: this.state.signup.id, name: this.state.signup.name, username: this.state.signup.username, email: this.state.signup.username,
                address: {
                    street: this.state.signup.address.street, suite: this.state.signup.address.suite, city: this.state.signup.address.city,
                    zipcode: this.state.signup.address.zipcode, geo: { lat: this.state.signup.address.geo.lat, lng: this.state.signup.address.geo.lat }
                },
                phone: this.state.signup.phone, website: this.state.signup.website
            }
        });
    }

    addPostTitleHandller = (event) => {
        this.setState({ addPost: { title: event.target.value } });
    }

    addPostBodyHandller = (event) => {
        this.setState({ addPost: { title: this.state.addPost.title, body: event.target.value } });
        
    }
    addPostBodyOnly = (event) => {
        this.setState({ addPost: { ... this.state.addPost, body: event.target.value } });
        
    }

    savePostHandler = () => {
        console.log(this.state.post.push(this.state.addPost));
        console.log(this.state);
        this.setState({ addPost: this.state.addPost });
    }

    


    render() {

        const userList = this.state.users.map(item => {
            return <Users key={item.id} username={item.name} post={() => this.postHandler(item.id)} />
        });
        const postList = this.state.post.map(item => {
            return <PostList key={item.id} title={item.title} body={item.body} comment={() => this.commentHandler(item.id)} />
        });
        const commentList = this.state.comment.map(item => {
            return <CommentList key={item.id} name={item.name} email={item.email} body={item.body} removeComment={() => this.removeCommentHandler(item.id)} />
        });

        let addPost;
        if (postList.length > 0) {
            addPost = <div>
                <form className="users">
                    <b>Add Post</b><br></br>
                    <label>Title</label><br />
                    <input type="text" onChange={this.addPostTitleHandller} /><br />
                    <label>Body</label><br />
                    <input type="text" onChange={this.addPostBodyOnly} /><br />
                    <button type="button" onClick={this.savePostHandler}>Save</button>
                </form>
            </div>;
        }
        else {
            addPost = <div>
                <b>Select any user to view the post</b>
            </div>
        }


        return (
            <div>
                <div className="SecondComponent">
                    <h3>Sign Up</h3>
                    <form className="signUpForm">
                        <label>Name  :</label>&nbsp;&nbsp;
                            <input type="text" onChange={this.formNameHandler} /><br /><br />
                        <label>Username  :</label>&nbsp;&nbsp;
                            <input type="text" onChange={this.formUserNameHandler} /><br /><br />
                        <label>Email  :</label>&nbsp;&nbsp;
                            <input type="text" onChange={this.formEmailHandler} /><br /><br />
                        <label>Street  :</label>&nbsp;&nbsp;
                            <input type="text" onChange={this.formStreetHandler} /><br /><br />
                        <label>Suite  :</label>&nbsp;&nbsp;
                            <input type="text" onChange={this.formSuiteHandler} /><br /><br />
                        <label>City  :</label>&nbsp;&nbsp;
                            <input type="text" onChange={this.formCityHandler} /><br /><br />
                        <label>Zipcode  :</label>&nbsp;&nbsp;
                            <input type="text" onChange={this.formZipcodeHandler} /><br /><br />
                        <label>Latitute  :</label>&nbsp;&nbsp;
                            <input type="text" onChange={this.formLatituteHandler} /><br /><br />
                        <label>Longitute  :</label>&nbsp;&nbsp;
                            <input type="text" onChange={this.formLongituteHandler} /><br /><br />
                        <label>Phone Number  :</label>&nbsp;&nbsp;
                            <input type="text" onChange={this.formPhoneNumberHandler} /><br /><br />
                        <label>Website  :</label>&nbsp;&nbsp;
                            <input type="text" onChange={this.formWebsiteHandler} /><br /><br />
                        <button type="button" onClick={this.formSignUphandler}>Signup</button><br /><br />
                    </form>
                </div>
                <div className="ThirdComponent">

                    {userList}
                    {postList}
                    {addPost}
                    <div>
                        {commentList}
                    </div>

                </div>
            </div>
        );
    }

    componentDidMount = () => {
        Axios.get("https://jsonplaceholder.typicode.com/users")
            .then(res => {
                this.setState({ users: res.data, post: this.state.post, signup: this.state.signup });
            })
    }

    shouldComponentUpdate = (nextProps, nextState) => {
        return true;
    }

    getSnapshotBeforeUpdate = (prevProps, prevState) => {
        return { message: 'Test' };
    }

    componentDidUpdate = () => {

    }
}


export default SignUp;