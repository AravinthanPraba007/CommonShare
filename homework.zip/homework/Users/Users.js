import React from 'react'

const Users = (props) => {

    return (
        <div>
            <div className="users">
                <table>
                    
                    <tbody>
                    <tr>
                    <td><h3>{props.username}</h3></td>
                    
                    
                    <td><button onClick={props.post}>POST</button></td>
                    </tr>
                    </tbody>
                   
                </table>
                
                
            </div>
            <hr></hr>

        </div>
    )
}

export default Users;