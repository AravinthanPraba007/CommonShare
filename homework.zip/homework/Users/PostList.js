import React from 'react'

const PostList = (props) => {

    return (
        <div className="FifthComponent">
            <div>

                <h5>Title</h5>
                {props.title}
                <h5>Body</h5>
                {props.body}<br></br>
                <button onClick={props.comment}>Comment</button>

            </div>
            <hr></hr>
        </div>
    )
}

export default PostList;