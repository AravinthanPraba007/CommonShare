import React from 'react'

const CommentList = (props) => {

    return (
        <div>
            <div className="ForthComponent">

                <h5>Name</h5>
                {props.name}<br />
                <h5>Email</h5>
                {props.email}<br />
                <h5>Body</h5>
                {props.body}<br />
                <button onClick={props.removeComment}>Remove Comment</button>

            </div>
            <hr></hr>

        </div>
    )
}

export default CommentList;